# 滚轮视差

## 方法

实时获取滚轮的位置，然后将文字背景实时移动

[来源](https://www.bilibili.com/video/BV1Ag411u7RH?spm_id_from=333.999.0.0&vd_source=e5d12c1cab2795094fb351bf2e212c4e)

<span style="color:#0000FF">对原来的稍作了修改</span>
